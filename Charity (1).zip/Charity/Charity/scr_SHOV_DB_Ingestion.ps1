﻿<#    
.SYNOPSIS       
   Powershell script for Data ingestion for the SourceHOV Charity & IS  Process
.DESCRIPTION
   Data ingestion for getting workitems via APIs for the SourceHOV  Charity & IS  Process

.PARAMETER ConfigFilePath
   File Path Location to the configuration file in which all the parameters required for the execution of this script are configured

.EXAMPLE       
   Powershell.exe "D:\PowershellScripts\scr_SHOV_DB_Ingestion.ps1" -ConfigFilePath "D:\PowershellScripts\SourceHOVISConfig_Powershell.csv" 
   .\scr_SHOV_DB_Ingestion.ps1 -ConfigFilePath "D:\PowershellScripts\SourceHOVISConfig_Powershell.csv" 
#>

[CmdletBinding()]
param (
    [Parameter (Mandatory = $true, Position = 0)] [string] $ConfigFilePath
)
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls -bor [Net.SecurityProtocolType]::Tls11 -bor [Net.SecurityProtocolType]::Tls12;
#region Function definitions
Function Get-UdfConfiguration { 
    [CmdletBinding()]
    param (
        [string] $configpath   
    )
    $configvals = Import-CSV -Path $configpath -Header name, value;

    $configlist = @{ };

    foreach ($item in $configvals) {
        $configlist.Add($item.name, $item.value)
    }   
    Return $configlist    
}

Function Write-Log {
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory = $False)]
        [ValidateSet("INFO", "WARN", "ERROR", "FATAL", "DEBUG", "EXECUTION")]
        [String]
        $Level = "INFO",

        [Parameter(Mandatory = $True)]
        [string]
        $Message,

        [Parameter(Mandatory = $False)]
        [string]
        $logfile
    )

    $Stamp = (Get-Date).toString("yyyy/MM/dd HH:mm:ss")
    $Content = [PSCustomObject]@{"Log Level" = $Level ; "Timestamp" = $Stamp; "CurrentTask" = $PSCommandPath; Message = $Message }
    If ($logfile) {
        try {
            $Content | Export-Csv -Path $logfile -NoTypeInformation -Append
        }
        catch {
            Write-Output $_.Exception.Message            
        }
    }
    Else {
        Write-Output $Message
    }
} 

Function Test-SQLConnection {    
    [OutputType([bool])]
    Param
    (
        [Parameter(Mandatory = $true,
            ValueFromPipelineByPropertyName = $true,
            Position = 0)]
        $ConnectionString
    )
    $ErrorMessage = $null
    try {
        $sqlConnection = New-Object System.Data.SqlClient.SqlConnection $ConnectionString;
        $sqlConnection.Open();        
    }
    catch {
        $ErrorMessage = $_ 

    }
    finally {
        $sqlConnection.Close();       
    }

    [PSCustomObject] @{
        Errors  = $ErrorMessage
        Success = if ($null -eq $ErrorMessage) { $true } else { $false }
    }
}

Function Invoke-UdfStoredProcedure { 
    [CmdletBinding()]
    param (
        [string] $sqlconnstring          , # Connection string
        [string] $sqlspname              , # SQL Query
        $parameterset                        # Parameter properties
    )
         
    $sqlDataAdapterError = $null
    try {
        $conn = new-object System.Data.SqlClient.SqlConnection($sqlconnstring);  

  
        $command = new-object system.data.sqlclient.Sqlcommand($sqlspname, $conn)

        $command.CommandType = [System.Data.CommandType]'StoredProcedure'; 

        foreach ($parm in $parameterset) {
            if ($parm.Direction -eq 'Input') {
                [void]$command.Parameters.AddWithValue($parm.Name, $parm.Value); 
            }
        }

        [void] $conn.Open()
  
        $adapter = New-Object System.Data.sqlclient.sqlDataAdapter $command
        $dataset = New-Object System.Data.DataSet
  
        [void] $adapter.Fill($dataset)
 
    }
    catch {
        $sqlDataAdapterError = $_
        $dataset = $null
        
    }
    finally {
        $conn.Close()  
    }

    [PSCustomObject] @{
        DataSet = $dataSet
        Errors  = $sqlDataAdapterError
        Success = if ($null -eq $sqlDataAdapterError) { $true } else { $false }
    }
 
}

Function Add-UdfParameter { 
    [CmdletBinding()]
    param (
        [string] $name                    , # Parameter name from stored procedure, i.e. @myparm
        [string] $direction               , # Input or Output or InputOutput
        [string] $value                   , # parameter value
        [string] $datatype                , # db data type, i.e. string, int64, etc.
        [int]    $size                        # length
    )

    $parm = New-Object System.Object
    $parm | Add-Member -MemberType NoteProperty -Name "Name" -Value "$name"
    $parm | Add-Member -MemberType NoteProperty -Name "Direction" -Value "$direction"
    $parm | Add-Member -MemberType NoteProperty -Name "Value" -Value "$value"
    $parm | Add-Member -MemberType NoteProperty -Name "Datatype" -Value "$datatype"
    $parm | Add-Member -MemberType NoteProperty -Name "Size" -Value "$size"

    Write-Output $parm
    
}

Function Invoke-udfExecDTOReporting {
    [CmdletBinding()]
    param (
        [string] $connstring          , # Connection string
        [string] $spName              , # SQL Query
        [string] $Rptjson
              
    )
    $parmset = @()   # Create a collection object.

    # Add the parameters we need to use...
    $parmset += (Add-UdfParameter "@RptJson" "Input" "$Rptjson" "string" -1)
    $spExecParams = @{
        sqlconnstring = $connstring
        sqlspname     = $spname
        parameterset  = $parmset
    }
    Invoke-UdfStoredProcedure @spExecParams;
}

Function Invoke-udfDTOReporting {
    [CmdletBinding()]
    param (
        [string] $rptconnstring          , # Connection string
        [string] $rptspname              , # SQL Query
        $DTOReportData                        # Parameter properties
    )

    $DTOReportJson = ConvertTo-Json -InputObject $DTOReportData

    Invoke-udfExecDTOReporting -connstring $rptconnstring -spname $rptspname -Rptjson $DTOReportJson;

}

Function Invoke-udfExecInsertWorkListSP {
    [CmdletBinding()]
    param (
        [string] $connstring          , # Connection string
        [string] $spName              , # SQL Query
        [string] $pWorkListjson        # SP Parameter
                 
    )
    $parmset = @()   # Create a collection object.
   
    # Add the parameters we need to use...
    $parmset += (Add-UdfParameter "@json" "Input" "$pWorkListjson" "string" -1)
   
    $spExecParams = @{
        sqlconnstring = $connstring
        sqlspname     = $spname
        parameterset  = $parmset
    }
    Invoke-UdfStoredProcedure @spExecParams;
}

Function Invoke-udfExecCheckoutAccountSP {
    [CmdletBinding()]
    param (
        [string] $connstring          , # Connection string
        [string] $spName              , # SQL Query
        [string] $pAcntjson        # SP Parameter
                 
    )
    $parmset = @()   # Create a collection object.
   
    # Add the parameters we need to use...
    $parmset += (Add-UdfParameter "@AccntJSON" "Input" "$pAcntjson" "string" -1)
   
    $spExecParams = @{
        sqlconnstring = $connstring
        sqlspname     = $spname
        parameterset  = $parmset
    }
    Invoke-UdfStoredProcedure @spExecParams;
}

Function Get-udfToken {
    [CmdletBinding()]
    param (
        [string] $EndPoint,
        [string] $clientID,
        [string] $clientSecret
    )
    ####### Token Generation ########
    $Method = "GET"
    $ContentType = "application/json"
    $ApiError = $null
    $params = @{
        Uri         = $EndPoint
        Method      = $Method
        ContentType = $ContentType
        Headers     = @{ 
            'clientId'     = "$clientID"  
            'clientSecret' = "$clientSecret" 
        }
    }
    try {
        $rToken = Invoke-RestMethod @params         
    }
    catch {
        $ApiError = $_;
        $rToken = $null;
    }

    #return $rToken
    [PSCustomObject] @{
        TokenDet = $rToken
        Errors   = $ApiError
        Success  = if ($null -eq $ApiError) { $true } else { $false }
    }


    ####### Token Generation ########
}


Function Invoke-udfAPIWorkList {
    [CmdletBinding()]
    param (
        [string] $EndPoint,
        [string] $token
    )

    $Method = "GET"
    $ContentType = "application/json"
    $ApiError = $null
    $params = @{
        Uri         = $EndPoint
        Method      = $Method
        ContentType = $ContentType
        Headers     = @{ 
            'Authorization' = "Bearer $token"
        }
    }
    try {
        $response = Invoke-RestMethod @params         
    }
    catch {
        $ApiError = $_;
        $response = $null;
    }

    #return $rToken
    [PSCustomObject] @{
        WorkListDet = $response
        Errors      = $ApiError
        Success     = if ($null -eq $ApiError) { $true } else { $false }
    }
    
}

Function Invoke-udfAPICheckoutAccount {
    [CmdletBinding()]
    param (
        [string] $EndPoint,
        [string] $token,
        [string] $FacilityCode,
        [string] $jsonbody
    )

    $Method = "PUT"
    $ContentType = "application/json"
    $ApiError = $null
    $params = @{
        Uri         = $EndPoint
        Method      = $Method
        ContentType = $ContentType
        Headers     = @{ 
            'facilityCode'  = "$FacilityCode"                   
            'Authorization' = "Bearer $token"
        }
        Body        = $jsonbody
    }
    try {
        $response = Invoke-RestMethod @params         
    }
    catch {
        $ApiError = $_;
        $response = $null;
    }

    #return $rToken
    [PSCustomObject] @{
        AccountDet = $response
        Errors     = $ApiError
        Success    = if ($null -eq $ApiError) { $true } else { $false }
    }
    
}

#endregion Function definitions

#region Reading Config file
try {
    $config = Get-UdfConfiguration -configpath $ConfigFilePath -ErrorAction Stop
    Write-Output "Reading config file completed"
}
catch {
    Write-Output "Error while reading the config file"
    Write-Output $_.Exception.Message
    Write-Output "Bot Execution is stopped."
    Exit
}
#endregion Reading Config file

[bool]$isErrorExit = $false

#region Log file Initialization
if ([string]$null -ne $config.ProcessLogFilePath) {
    if ( -not ( Test-Path -Path $config.ProcessLogFilePath -PathType Container) ) {
        Write-Output "Log file folder location is not accessible or does not exists."
        Write-Output "Bot Execution is stopped."
        $isErrorExit = $true
    }
}
else {
    Write-Output "Log file folder location is blank."
    Write-Output "Bot Execution is stopped."    
    $isErrorExit = $true
}

$ProcessLogFilePath = Join-Path $config.ProcessLogFilePath (Get-Date).ToString('MM.dd.yyyy')
if ( -not (Test-Path -Path $ProcessLogFilePath -PathType Container) ) {
    New-Item -ItemType "directory" -Path $ProcessLogFilePath | Out-Null    
}

$LogFileName = $env:COMPUTERNAME + "_" + $Config.ProcessName + ".csv"
$LogFileName = Join-Path $ProcessLogFilePath $LogFileName;

#endregion

#region Config values validation
if ([string]$null -ne $config.PSDBConnectionString) {
    $DBTestConnection = Test-SQLConnection $config.PSDBConnectionString
    if ($DBTestConnection.Success -eq $false) {
        Write-Log -Level ERROR -Message $DBTestConnection.Errors.Exception.Message -logfile $LogFileName -ErrorAction Stop
        $isErrorExit = $true
    }
}
else {        
    Write-Log -Level ERROR -Message "Database connectionstring is not provided." -logfile $LogFileName -ErrorAction Stop
    $isErrorExit = $true
}

if ([string]$null -eq $config.InsertWorkListSP) {
    Write-Log -Level ERROR -Message "InsertWorkListSP is blank." -logfile $LogFileName -ErrorAction Stop
    $isErrorExit = $true
}
if ([string]$null -eq $config.GetWorkListSP) {
    Write-Log -Level ERROR -Message "GetWorkListSP is blank." -logfile $LogFileName -ErrorAction Stop
    $isErrorExit = $true
}
if ([string]$null -eq $config.CheckoutAccountSP) {
    Write-Log -Level ERROR -Message "CheckoutAccountSP is blank." -logfile $LogFileName -ErrorAction Stop
    $isErrorExit = $true
}
if ([string]$null -eq $config.DTOReportingSP) {
    Write-Log -Level ERROR -Message "DTOReportingSP is blank." -logfile $LogFileName -ErrorAction Stop
    $isErrorExit = $true
}
if ([string]$null -eq $config.SkipDTOReportingSP) {
    Write-Log -Level ERROR -Message "SkipDTOReportingSP is blank." -logfile $LogFileName -ErrorAction Stop
    $isErrorExit = $true
}

if ([string]$null -eq $config.PurgeDataSP) {
    Write-Log -Level ERROR -Message "PurgeDataSP is blank." -logfile $LogFileName -ErrorAction Stop
    $isErrorExit = $true
}

if ([string]$null -eq $config.APIBaseURL) {
    Write-Log -Level ERROR -Message "API Base URL is blank." -logfile $LogFileName -ErrorAction Stop
    $isErrorExit = $true
}

if ([string]$null -eq $config.APITokenGeneration) {
    Write-Log -Level ERROR -Message "API Base URL is blank." -logfile $LogFileName -ErrorAction Stop
    $isErrorExit = $true
}
if ([string]$null -eq $config.APIGetWorkList) {
    Write-Log -Level ERROR -Message "End point for Get Worklist API is blank." -logfile $LogFileName -ErrorAction Stop
    $isErrorExit = $true
}
if ([string]$null -eq $config.APICheckoutAccount) {
    Write-Log -Level ERROR -Message "Endpoint for Checkout Account API is blank." -logfile $LogFileName -ErrorAction Stop
    $isErrorExit = $true
}
if ([string]$null -eq $config.clientId) {
    Write-Log -Level ERROR -Message "clientId is blank." -logfile $LogFileName -ErrorAction Stop
    $isErrorExit = $true
}
if ([string]$null -eq $config.clientSecret) {
    Write-Log -Level ERROR -Message "clientSecret is blank." -logfile $LogFileName -ErrorAction Stop
    $isErrorExit = $true
}
if ([string]$null -eq $config.PerformerCode) {
    Write-Log -Level ERROR -Message "PerformerCode is blank." -logfile $LogFileName -ErrorAction Stop
    $isErrorExit = $true
}

if ([string]$null -eq $config.RequestTypes) {
    Write-Log -Level ERROR -Message "Request Type is blank." -logfile $LogFileName -ErrorAction Stop
    $isErrorExit = $true
}

if ($isErrorExit) {
    Write-Output "Bot Execution is stopped."
    Exit    
}
#endregion Config values validation

#region Calling Purge Data Sp
# Purge all the data for fresh processing
$PurgeSPParams = @{
    sqlconnstring = $config.PSDBConnectionString
    sqlspname     = $config.PurgeDataSP
}
$PurgeData = Invoke-UdfStoredProcedure @PurgeSPParams;
if ($PurgeData.Success -eq $false) {
    Write-Log -Level ERROR -Message "Error while purging the data." -logfile $LogFileName -ErrorAction Stop;
    Write-Log -Level ERROR -Message $PurgeData.Errors.Exception.Message -logfile $LogFileName -ErrorAction Stop;
}

#endregion

#region Calling Token Generation API
$token = $null
Write-Log -Level INFO -Message "Calling Token generation API" -logfile $LogFileName

$tokenresponse = Get-udfToken -EndPoint ( -join ($config.APIBaseURL, $config.APITokenGeneration)) -clientID $config.clientID -clientSecret $config.clientSecret -ErrorAction Stop
if ($tokenresponse.Success -eq $true) {
    $token = $tokenresponse.TokenDet.token;
    Write-Log -Level INFO -Message "Token generated successfully" -logfile $LogFileName;
}
else {
    Write-Log -Level ERROR -Message "Error during Token Generation API call." -logfile $LogFileName -ErrorAction Stop;
    Write-Log -Level ERROR -Message $tokenresponse.Errors.Exception.Message -logfile $LogFileName -ErrorAction Stop
    if ($tokenresponse.Errors.ErrorDetails.Message) {
        Write-Log -Level ERROR -Message $tokenresponse.Errors.ErrorDetails.Message -logfile $LogFileName -ErrorAction Stop    
    }    
    Write-Output "Bot Execution Stopped."
    Exit
}
#endregion 

foreach ($RequestType in $config.RequestTypes.Split("|")) {
    #region Call Worklist API
    $WorkListAPIparams = @{
        EndPoint = -join ($config.APIBaseURL, $config.APIGetWorkList, $RequestType)
        token    = $token
    }

    $WorklistResponse = Invoke-udfAPIWorkList @WorkListAPIparams;

    if ($WorklistResponse.Success -eq $true) {
        $WorkListjson = $WorklistResponse.WorkListDet | ConvertTo-Json -Depth 10;
        if ($WorkListjson) {
            Write-Log -Level INFO -Message "Response received from Get Worklist API successfully" -logfile $LogFileName -ErrorAction Stop;
            $worklistspParams = @{
                connstring    = $config.PSDBConnectionString
                spname        = $config.InsertWorkListSP
                pWorkListjson = $WorkListjson
            }                            
            $InsertWorkListData = Invoke-udfExecInsertWorkListSP @worklistspParams;

            if ($InsertWorkListData.Success -eq $true) {
                Write-Log -Level INFO -Message "json parsing done successfully" -logfile $LogFileName;
            }
            else {
                Write-Log -Level ERROR -Message "Error while parsing the json." -logfile $LogFileName -ErrorAction Stop;
                Write-Log -Level ERROR -Message $InsertWorkListData.Errors.Exception.Message -logfile $LogFileName -ErrorAction Stop;
            }

        }
    }
    else {
        Write-Log -Level ERROR -Message "Error during Get Worklist API call." -logfile $LogFileName -ErrorAction Stop;
        
        # if ($WorklistResponse.Errors.Exception.Response.StatusCode.value__ ) {
        #     Write-Log -Level INFO -Message ("StatusCode:" + $WorklistResponse.Errors.Exception.Response.StatusCode.value__ ) -logfile $LogFileName -ErrorAction Stop
        #     Write-Log -Level INFO -Message ("StatusCode:" + $WorklistResponse.Errors.Exception.Response.StatusDescription) -logfile $LogFileName -ErrorAction Stop
        # }
        Write-Log -Level ERROR -Message $WorklistResponse.Errors.Exception.Message -logfile $LogFileName -ErrorAction Stop;        
        if ($WorklistResponse.Errors.ErrorDetails.Message) {
            Write-Log -Level ERROR -Message $WorklistResponse.Errors.ErrorDetails.Message -logfile $LogFileName -ErrorAction Stop;
        }        
    }
    #endregion
}


#region Checkout Account

Write-Log -Level INFO -Message "Preparing worklist for checkout account API" -logfile $LogFileName;

$GetWorkListSPParams = @{
    sqlconnstring = $config.PSDBConnectionString
    sqlspname     = $config.GetWorkListSP
}
$WorkListData = Invoke-UdfStoredProcedure @GetWorkListSPParams;

if ($WorkListData.Success -eq $true) {

    if ($WorkListData.DataSet.Tables[0].Rows.Count -gt 0) {
        Write-Log -Level INFO -Message "Worklist items found" -logfile $LogFileName;
    
        foreach ($WorkListItem in $WorkListData.DataSet.Tables[0].Rows) {


            # DTO Reporting details
            $ReportDet = [PSCustomObject]@{
                UserID            = $env:USERNAME
                BotName           = $env:COMPUTERNAME
                FacilityCode      = $WorkListItem.FacilityCode
                AccountNumber     = $WorkListItem.AccountNo
                ProcessName       = $Config.ProcessName
                ProcessStatus     = $null
                LogFilePath       = $LogFileName
                StartProcess      = (Get-date -Format "yyyy-MM-dd HH:mm:ss:fff")
                EndProcess        = $null
                StatusDescription = $null
                RequestType       = $WorkListItem.RequestType
                MRN               = $WorkListItem.MRN
            }
            #region Calling Token Generation API
            $token = $null
            Write-Log -Level INFO -Message "Calling Token generation API" -logfile $LogFileName

            $tokenresponse = Get-udfToken -EndPoint ( -join ($config.APIBaseURL, $config.APITokenGeneration)) -clientID $config.clientID -clientSecret $config.clientSecret -ErrorAction Stop
            if ($tokenresponse.Success -eq $true) {
                $token = $tokenresponse.TokenDet.token;
                Write-Log -Level INFO -Message "Token generated successfully" -logfile $LogFileName;
            }
            else {
                Write-Log -Level ERROR -Message "Error during Token Generation API call." -logfile $LogFileName -ErrorAction Stop;
                Write-Log -Level ERROR -Message $tokenresponse.Errors.Exception.Message -logfile $LogFileName -ErrorAction Stop
                if ($tokenresponse.Errors.ErrorDetails.Message) {
                    Write-Log -Level ERROR -Message $tokenresponse.Errors.ErrorDetails.Message -logfile $LogFileName -ErrorAction Stop    
                }
                $ReportDet.ProcessStatus = "Fail"
                $ReportDet.StatusDescription = $tokenresponse.Errors.Exception.Message;
                $ReportDet.EndProcess = (Get-date -Format "yyyy-MM-dd HH:mm:ss:fff");

                $DTOspExecParams = @{
                    rptconnstring = $config.PSDBConnectionString
                    rptspname     = $config.DTOReportingSP
                    DTOReportData = $ReportDet
                }
                $DTORptDet = Invoke-udfDTOReporting @DTOspExecParams;
                if ($DTORptDet.Success -eq $false) {
                    Write-Log -Level ERROR -Message "Error during DTO Reporting"  -logfile $LogFileName
                    Write-Log -Level ERROR -Message  $DTORptDet.Errors.Exception.Message -logfile $LogFileName
                }
                Write-Output "Bot Execution Stopped."
                Exit
            }
            #endregion 
            [string]$RequestNo = $WorkListItem.RequestNo
            [string]$AccountNo = $WorkListItem.AccountNo
            [string]$PerformerCode = $config.PerformerCode
            [string]$Wid = $WorkListItem.WorklistID.ToString()
            [string]$reqType = $WorkListItem.RequestType
            [string]$FacilityCode = $WorkListItem.FacilityCode
            [string]$jsonbody = @"
{
"focus": {
"type": "Account",
"reference": "$RequestNo",
"display": "$reqType",
"identifier": {
"type": "AccountNumber",
"value": "$AccountNo"
}
},
"performer": {
"type": "user",
"code": "$PerformerCode"
}
}
"@

            Write-Log -Level INFO -Message "Calling Checkout Account API for Account Number: $AccountNo and FacilityCode: $FacilityCode" -logfile $LogFileName;
            Write-Log -Level INFO -Message $jsonbody -logfile $LogFileName;

            $Checkoutjson = $null
            $ChkAccntAPIparams = @{
                EndPoint     = -join ($config.APIBaseURL, $config.APICheckoutAccount)
                token        = $token
                FacilityCode = $FacilityCode
                jsonbody     = $jsonbody
            }
            $CheckOutResponse = Invoke-udfAPICheckoutAccount @ChkAccntAPIparams;
        
            if ($CheckOutResponse.Success -eq $true) {

                $Checkoutjson = $CheckOutResponse.AccountDet | ConvertTo-Json -Depth 10;

                if ($Checkoutjson) {
                    Write-Log -Level INFO -Message "Response received from Checkout Account API successfully for Account Number: $AccountNo and FacilityCode: $FacilityCode" -logfile $LogFileName

                    $chkAcntspParams = @{
                        connstring = $config.PSDBConnectionString
                        spName     = $config.CheckoutAccountSP
                        pAcntjson  = $Checkoutjson
                    }                            
                    $checkoutdata = Invoke-udfExecCheckoutAccountSP @chkAcntspParams;
                
                    if ($checkoutdata.Success -eq $true) {
                        Write-Log -Level INFO -Message "json parsing done successfully for Account Number: $AccountNo and FacilityCode: $FacilityCode" -logfile $LogFileName;
                    }
                    else {
                        Write-Log -Level ERROR -Message "Error while parsing the json for Account Number: $AccountNo and FacilityCode: $FacilityCode" -logfile $LogFileName -ErrorAction Stop
                        Write-Log -Level ERROR -Message $checkoutdata.Errors.Exception.Message -logfile $LogFileName -ErrorAction Stop
                        $ReportDet.ProcessStatus = "Fail"
                        $ReportDet.StatusDescription = $checkoutdata.Errors.Exception.Message;
                        $ReportDet.EndProcess = (Get-date -Format "yyyy-MM-dd HH:mm:ss:fff");
        
                        $DTOspExecParams = @{
                            rptconnstring = $config.PSDBConnectionString
                            rptspname     = $config.DTOReportingSP
                            DTOReportData = $ReportDet
                        }
                        $DTORptDet = Invoke-udfDTOReporting @DTOspExecParams;
                        
                        if ($DTORptDet.Success -eq $false) {
                            Write-Log -Level ERROR -Message "Error during DTO Reporting"  -logfile $LogFileName
                            Write-Log -Level ERROR -Message  $DTORptDet.Errors.Exception.Message -logfile $LogFileName
                        }                        
                    }                    

                } 

            }
            else {
                
                Write-Log -Level ERROR -Message "Error during Checkout Account API call for Account Number: $AccountNo and FacilityCode: $FacilityCode" -logfile $LogFileName -ErrorAction Stop
                Write-Log -Level ERROR -Message $CheckOutResponse.Errors.Exception.Message -logfile $LogFileName -ErrorAction Stop
                if ($CheckOutResponse.Errors.ErrorDetails.Message) {
                    Write-Log -Level ERROR -Message $CheckOutResponse.Errors.ErrorDetails.Message -logfile $LogFileName -ErrorAction Stop
                }
                $ReportDet.ProcessStatus = "Fail"
                $ReportDet.StatusDescription = $CheckOutResponse.Errors.Exception.Message;
                $ReportDet.EndProcess = (Get-date -Format "yyyy-MM-dd HH:mm:ss:fff");

                $DTOspExecParams = @{
                    rptconnstring = $config.PSDBConnectionString
                    rptspname     = $config.DTOReportingSP
                    DTOReportData = $ReportDet
                }
                $DTORptDet = Invoke-udfDTOReporting @DTOspExecParams;
                
                if ($DTORptDet.Success -eq $false) {
                    Write-Log -Level ERROR -Message "Error during DTO Reporting"  -logfile $LogFileName
                    Write-Log -Level ERROR -Message  $DTORptDet.Errors.Exception.Message -logfile $LogFileName
                }
		        
            }
        }
    }
    else {
        Write-Output ('No Accounts to be checkout out.')       
        Write-Log -Level INFO -Message "No Pending accounts to be processed. All accounts have been checked out." -logfile $LogFileName             
    }

    #region Calling Validation Procedure    
    if ( $config.ValidationSP.Length -gt 0){
        $ValidationSPParams = @{
            sqlconnstring = $config.PSDBConnectionString
            sqlspname     = $config.ValidationSP
        }
        $ValidationData = Invoke-UdfStoredProcedure @ValidationSPParams;

        if ($ValidationData.Success -eq $false) {
        Write-Log -Level ERROR -Message "Error while execution ValidationSP." -logfile $LogFileName -ErrorAction Stop;
        Write-Log -Level ERROR -Message $ValidationData.Errors.Exception.Message -logfile $LogFileName -ErrorAction Stop;
        }
    }
    #endregion

    #region DTO Logging for skip & success cases all at once using sp
    $SkipReportDet = [PSCustomObject] @{
        UserID      = $env:USERNAME
        BotName     = $env:COMPUTERNAME
        ProcessName = $Config.ProcessName
        LogFilePath = $LogFileName                        
    }

    $DTOspExecParams = @{
        rptconnstring = $config.PSDBConnectionString
        rptspname     = $config.SkipDTOReportingSP
        DTOReportData = $SkipReportDet
    }
    $DTORptDet = Invoke-udfDTOReporting @DTOspExecParams;
    if ($DTORptDet.Success -eq $false) {
        Write-Log -Level ERROR -Message "Error during DTO Reporting for skip cases."  -logfile $LogFileName
        Write-Log -Level ERROR -Message  $DTORptDet.Errors.Exception.Message -logfile $LogFileName
    }
    #endregion

}
else {
    Write-Log -Level ERROR -Message $WorkListData.Errors.Exception.Message -logfile $LogFileName -ErrorAction Stop        
}

#endregion Checkout Account


Write-Log -Level INFO -Message "Data ingestion is completed." -logfile $LogFileName
Write-Log -Level INFO -Message "End of Bot execution." -logfile $LogFileName
Write-Output "End of Bot Execution."
