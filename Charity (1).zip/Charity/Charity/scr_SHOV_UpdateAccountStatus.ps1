﻿<#    
.SYNOPSIS       
   Powershell script for Updating Account Status
.DESCRIPTION
   Updating status of accounts for IS & Charity Process

.PARAMETER ConfigFilePath
   File Path Location to the configuration file in which all the parameters required for the execution of this script are configured

.EXAMPLE       
   Powershell.exe "D:\PowershellScripts\scr_SHOV_UpdateAccountStatus.ps1" -ConfigFilePath "D:\PowershellScripts\SourceHOVISConfig_Powershell.csv" 
   .\scr_SHOV_UpdateAccountStatus.ps1 -ConfigFilePath "D:\PowershellScripts\SourceHOVISConfig_Powershell.csv" 
#>

[CmdletBinding()]
param (
    [Parameter (Mandatory = $true, Position = 0)] [string] $ConfigFilePath
)
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls -bor [Net.SecurityProtocolType]::Tls11 -bor [Net.SecurityProtocolType]::Tls12;
#region Function definitions
Function Get-UdfConfiguration { 
    [CmdletBinding()]
    param (
        [string] $configpath   
    )
    $configvals = Import-CSV -Path $configpath -Header name, value;

    $configlist = @{ };

    foreach ($item in $configvals) {
        $configlist.Add($item.name, $item.value)
    }   
    Return $configlist    
}

Function Write-Log {
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory = $False)]
        [ValidateSet("INFO", "WARN", "ERROR", "FATAL", "DEBUG", "EXECUTION")]
        [String]
        $Level = "INFO",

        [Parameter(Mandatory = $True)]
        [string]
        $Message,

        [Parameter(Mandatory = $False)]
        [string]
        $logfile
    )

    $Stamp = (Get-Date).toString("yyyy/MM/dd HH:mm:ss")
    $Content = [PSCustomObject]@{"Log Level" = $Level ; "Timestamp" = $Stamp; "CurrentTask" = $PSCommandPath; Message = $Message }
    If ($logfile) {
        try {
            $Content | Export-Csv -Path $logfile -NoTypeInformation -Append
        }
        catch {
            Write-Host $_.Exception.Message            
        }
    }
    Else {
        Write-Host $Message
    }
} 

Function Test-SQLConnection {    
    [OutputType([bool])]
    Param
    (
        [Parameter(Mandatory = $true,
            ValueFromPipelineByPropertyName = $true,
            Position = 0)]
        $ConnectionString
    )
    $ErrorMessage = $null
    try {
        $sqlConnection = New-Object System.Data.SqlClient.SqlConnection $ConnectionString;
        $sqlConnection.Open();        
    }
    catch {
        $ErrorMessage = $_ 

    }
    finally {
        $sqlConnection.Close();       
    }

    [PSCustomObject] @{
        Errors  = $ErrorMessage
        Success = if ($null -eq $ErrorMessage) { $true } else { $false }
    }
}

Function Invoke-UdfStoredProcedure { 
    [CmdletBinding()]
    param (
        [string] $sqlconnstring          , # Connection string
        [string] $sqlspname              , # SQL Query
        $parameterset                        # Parameter properties
    )
         
    $sqlDataAdapterError = $null
    try {
        $conn = new-object System.Data.SqlClient.SqlConnection($sqlconnstring);  

  
        $command = new-object system.data.sqlclient.Sqlcommand($sqlspname, $conn)

        $command.CommandType = [System.Data.CommandType]'StoredProcedure'; 

        foreach ($parm in $parameterset) {
            if ($parm.Direction -eq 'Input') {
                [void]$command.Parameters.AddWithValue($parm.Name, $parm.Value); 
            }
        }

        [void] $conn.Open()
  
        $adapter = New-Object System.Data.sqlclient.sqlDataAdapter $command
        $dataset = New-Object System.Data.DataSet
  
        [void] $adapter.Fill($dataset)
 
    }
    catch {
        $sqlDataAdapterError = $_
        $dataset = $null
        
    }
    finally {
        $conn.Close()  
    }

    [PSCustomObject] @{
        DataSet = $dataSet
        Errors  = $sqlDataAdapterError
        Success = if ($null -eq $sqlDataAdapterError) { $true } else { $false }
    }
 
}

Function Add-UdfParameter { 
    [CmdletBinding()]
    param (
        [string] $name                    , # Parameter name from stored procedure, i.e. @myparm
        [string] $direction               , # Input or Output or InputOutput
        [string] $value                   , # parameter value
        [string] $datatype                , # db data type, i.e. string, int64, etc.
        [int]    $size                        # length
    )

    $parm = New-Object System.Object
    $parm | Add-Member -MemberType NoteProperty -Name "Name" -Value "$name"
    $parm | Add-Member -MemberType NoteProperty -Name "Direction" -Value "$direction"
    $parm | Add-Member -MemberType NoteProperty -Name "Value" -Value "$value"
    $parm | Add-Member -MemberType NoteProperty -Name "Datatype" -Value "$datatype"
    $parm | Add-Member -MemberType NoteProperty -Name "Size" -Value "$size"

    Write-Output $parm
    
}

Function Invoke-udfExecDTOReporting {
    [CmdletBinding()]
    param (
        [string] $connstring          , # Connection string
        [string] $spName              , # SQL Query
        [string] $Rptjson
              
    )
    $parmset = @()   # Create a collection object.

    # Add the parameters we need to use...
    $parmset += (Add-UdfParameter "@RptJson" "Input" "$Rptjson" "string" -1)
    $spExecParams = @{
        sqlconnstring = $connstring
        sqlspname     = $spname
        parameterset  = $parmset
    }
    Invoke-UdfStoredProcedure @spExecParams;
}

Function Invoke-udfDTOReporting {
    [CmdletBinding()]
    param (
        [string] $rptconnstring          , # Connection string
        [string] $rptspname              , # SQL Query
        $DTOReportData                        # Parameter properties
    )

    $DTOReportJson = ConvertTo-Json -InputObject $DTOReportData

    Invoke-udfExecDTOReporting -connstring $rptconnstring -spname $rptspname -Rptjson $DTOReportJson;

}

Function Get-udfToken {
    [CmdletBinding()]
    param (
        [string] $EndPoint,
        [string] $clientID,
        [string] $clientSecret
    )
    ####### Token Generation ########
    $Method = "GET"
    $ContentType = "application/json"
    $ApiError = $null
    $params = @{
        Uri         = $EndPoint
        Method      = $Method
        ContentType = $ContentType
        Headers     = @{ 
            'clientId'     = "$clientID"  
            'clientSecret' = "$clientSecret" 
        }
    }
    try {
        $rToken = Invoke-RestMethod @params         
    }
    catch {
        $ApiError = $_;
        $rToken = $null;
    }

    #return $rToken
    [PSCustomObject] @{
        TokenDet = $rToken
        Errors   = $ApiError
        Success  = if ($null -eq $ApiError) { $true } else { $false }
    }


    ####### Token Generation ########
}


Function Invoke-udfAPICheckoutAccount {
    [CmdletBinding()]
    param (
        [string] $EndPoint,
        [string] $token,
        [string] $FacilityCode,
        [string] $jsonbody
    )

    $Method = "PUT"
    $ContentType = "application/json"
    $ApiError = $null
    $params = @{
        Uri         = $EndPoint
        Method      = $Method
        ContentType = $ContentType
        Headers     = @{ 
            'facilityCode'  = "$FacilityCode"                   
            'Authorization' = "Bearer $token"
        }
        Body        = $jsonbody
    }
    try {
        $response = Invoke-RestMethod @params         
    }
    catch {
        $ApiError = $_;
        $response = $null;
    }

    #return $rToken
    [PSCustomObject] @{
        AccountDet = $response
        Errors     = $ApiError
        Success    = if ($null -eq $ApiError) { $true } else { $false }
    }
    
}

#endregion Function definitions

#region Reading Config file
try {
    $config = Get-UdfConfiguration -configpath $ConfigFilePath -ErrorAction Stop
    Write-Host "Reading config file completed"
}
catch {
    Write-Host "Error while reading the config file"
    Write-Host $_.Exception.Message
    Write-Host "Bot Execution is stopped."
    Exit
}
#endregion Reading Config file

[bool]$isErrorExit = $false

#region Log file Initialization
if ([string]$null -ne $config.ProcessLogFilePath) {
    if ( -not ( Test-Path -Path $config.ProcessLogFilePath -PathType Container) ) {
        Write-Host "Log file folder location is not accessible or does not exists."
        Write-Host "Bot Execution is stopped."
        $isErrorExit = $true
    }
}
else {
    Write-Host "Log file folder location is blank."
    Write-Host "Bot Execution is stopped."    
    $isErrorExit = $true
}

$ProcessLogFilePath = Join-Path $config.ProcessLogFilePath (Get-Date).ToString('MM.dd.yyyy')
if ( -not (Test-Path -Path $ProcessLogFilePath -PathType Container) ) {
    New-Item -ItemType "directory" -Path $ProcessLogFilePath | Out-Null    
}

$LogFileName = $env:COMPUTERNAME + "_" + $Config.ProcessName + ".csv"
$LogFileName = Join-Path $ProcessLogFilePath $LogFileName;

#endregion

#region Config values validation
if ([string]$null -ne $config.PSDBConnectionString) {
    $DBTestConnection = Test-SQLConnection $config.PSDBConnectionString
    if ($DBTestConnection.Success -eq $false) {
        Write-Log -Level ERROR -Message $DBTestConnection.Errors.Exception.Message -logfile $LogFileName -ErrorAction Stop
        $isErrorExit = $true
    }
}
else {        
    Write-Log -Level ERROR -Message "Database connectionstring is not provided." -logfile $LogFileName -ErrorAction Stop
    $isErrorExit = $true
}

if ([string]$null -eq $config.GetDetailsForUpdateAccountSP) {
    Write-Log -Level ERROR -Message "GetDetailsForUpdateAccountSP is blank." -logfile $LogFileName -ErrorAction Stop
    $isErrorExit = $true
}

if ([string]$null -eq $config.DTOReportingSP) {
    Write-Log -Level ERROR -Message "DTOReportingSP is blank." -logfile $LogFileName -ErrorAction Stop
    $isErrorExit = $true
}


if ([string]$null -eq $config.APIBaseURL) {
    Write-Log -Level ERROR -Message "API Base URL is blank." -logfile $LogFileName -ErrorAction Stop
    $isErrorExit = $true
}

if ([string]$null -eq $config.APITokenGeneration) {
    Write-Log -Level ERROR -Message "API Base URL is blank." -logfile $LogFileName -ErrorAction Stop
    $isErrorExit = $true
}
if ($null -eq $config.APIUpdateAccountStatus) {
    Write-Log -Level ERROR -Message "Endpoint for Update Account Status API is blank." -logfile $LogFileName -ErrorAction Stop;
    $isErrorExit = $true
}
if ([string]$null -eq $config.clientId) {
    Write-Log -Level ERROR -Message "clientId is blank." -logfile $LogFileName -ErrorAction Stop
    $isErrorExit = $true
}
if ([string]$null -eq $config.clientSecret) {
    Write-Log -Level ERROR -Message "clientSecret is blank." -logfile $LogFileName -ErrorAction Stop
    $isErrorExit = $true
}
if ([string]$null -eq $config.PerformerCode) {
    Write-Log -Level ERROR -Message "PerformerCode is blank." -logfile $LogFileName -ErrorAction Stop
    $isErrorExit = $true
}


if ($isErrorExit) {
    Write-Host "Bot Execution is stopped."
    Exit    
}
#endregion Config values validation


#region Calling Token Generation API
$token = $null
Write-Log -Level INFO -Message "Calling Token generation API" -logfile $LogFileName

$tokenresponse = Get-udfToken -EndPoint ( -join ($config.APIBaseURL, $config.APITokenGeneration)) -clientID $config.clientID -clientSecret $config.clientSecret -ErrorAction Stop
if ($tokenresponse.Success -eq $true) {
    $token = $tokenresponse.TokenDet.token;
    Write-Log -Level INFO -Message "Token generated successfully" -logfile $LogFileName;
}
else {
    Write-Log -Level ERROR -Message "Error during Token Generation API call." -logfile $LogFileName -ErrorAction Stop;
    Write-Log -Level ERROR -Message $tokenresponse.Errors.Exception.Message -logfile $LogFileName -ErrorAction Stop
    if ($tokenresponse.Errors.ErrorDetails.Message) {
        Write-Log -Level ERROR -Message $tokenresponse.Errors.ErrorDetails.Message -logfile $LogFileName -ErrorAction Stop    
    }    
    Write-Host "Bot Execution Stopped."
    Exit
}
#endregion 


#region Update Account Status

Write-Log -Level INFO -Message "Preparing worklist for Update account status API" -logfile $LogFileName;

$GetWorkListSPParams = @{
    sqlconnstring = $config.PSDBConnectionString
    sqlspname     = $config.GetDetailsForUpdateAccountSP
}
$AccountData = Invoke-UdfStoredProcedure @GetWorkListSPParams;

if ($AccountData.Success -eq $true) {

    if ($AccountData.DataSet.Tables[0].Rows.Count -gt 0) {

        Write-Log -Level INFO -Message "Accounts found for updating status" -logfile $LogFileName;
    
        foreach ($AccountItem in $AccountData.DataSet.Tables[0].Rows) {

            # DTO Reporting details
            $ReportDet = [PSCustomObject]@{
                UserID            = $env:USERNAME
                BotName           = $env:COMPUTERNAME
                FacilityCode      = $AccountItem.FacilityCode
                AccountNumber     = $AccountItem.AccountNumber
                ProcessName       = ( -join ($Config.ProcessName, "_UpdateAccountStatus"))
                ProcessStatus     = $null
                LogFilePath       = $LogFileName
                StartProcess      = (Get-date -Format "yyyy-MM-dd HH:mm:ss:fff")
                EndProcess        = $null
                StatusDescription = $null
                RequestType       = $AccountItem.RequestType
                MRN               = $AccountItem.MRN
            }
            #region Calling Token Generation API
            $token = $null
            Write-Log -Level INFO -Message "Calling Token generation API" -logfile $LogFileName

            $tokenresponse = Get-udfToken -EndPoint ( -join ($config.APIBaseURL, $config.APITokenGeneration)) -clientID $config.clientID -clientSecret $config.clientSecret -ErrorAction Stop
            if ($tokenresponse.Success -eq $true) {
                $token = $tokenresponse.TokenDet.token;
                Write-Log -Level INFO -Message "Token generated successfully" -logfile $LogFileName;
            }
            else {
                Write-Log -Level ERROR -Message "Error during Token Generation API call." -logfile $LogFileName -ErrorAction Stop;
                Write-Log -Level ERROR -Message $tokenresponse.Errors.Exception.Message -logfile $LogFileName -ErrorAction Stop
                if ($tokenresponse.Errors.ErrorDetails.Message) {
                    Write-Log -Level ERROR -Message $tokenresponse.Errors.ErrorDetails.Message -logfile $LogFileName -ErrorAction Stop    
                }
                $ReportDet.ProcessStatus = "Fail"
                $ReportDet.StatusDescription = $tokenresponse.Errors.Exception.Message;
                $ReportDet.EndProcess = (Get-date -Format "yyyy-MM-dd HH:mm:ss:fff");

                $DTOspExecParams = @{
                    rptconnstring = $config.PSDBConnectionString
                    rptspname     = $config.DTOReportingSP
                    DTOReportData = $ReportDet
                }
                $DTORptDet = Invoke-udfDTOReporting @DTOspExecParams;
                if ($DTORptDet.Success -eq $false) {
                    Write-Log -Level ERROR -Message "Error during DTO Reporting"  -logfile $LogFileName
                    Write-Log -Level ERROR -Message  $DTORptDet.Errors.Exception.Message -logfile $LogFileName
                }
                Write-Host "Bot Execution Stopped."
                Exit
            }
            #endregion 


            [string]$RequestNumber = $AccountItem.RequestNumber
            [string]$RequestType   = $AccountItem.RequestType
            [string]$AccountNumber = $AccountItem.AccountNumber
            [string]$performercode = $config.PerformerCode
            [string]$notes         = $AccountItem.Notes
            [string]$statuscode    = $AccountItem.StatusCode
            [string]$FacilityCode  = $AccountItem.FacilityCode

            [string]$status = $null
            switch ($statuscode) {
                1 { $status = "Pending" }
                2 { $status = "UnderReview" }
                3 { $status = "Dismissed" }
                4 { $status = "Completed" }
            }
            if (($notes -eq "BotMsg") -and ($statuscode -eq 1)){
                $notes = "Unable to process automatically. Please refer bot logs for exception occurred while processing this request."
            }
            elseif  ($statuscode -eq 4){
                $notes = "Processing Completed automatically."
            }

            $UpdateAccountJson = @"
{
  "focus": {
    "type": "Account",
    "reference": "$RequestNumber",
    "display": "$RequestType",
    "identifier": {
      "type": "AccountNumber",
      "value": "$AccountNumber"
    },
    
  },
  "performer": {
    "type": "user",
    "code": "$performercode"
  },
  "note": [
    {
      "text": "$notes"
    }
  ],
  "status": "$status"
}
"@

            Write-Log -Level INFO -Message "Calling Update account status API for Account Number: $AccountNumber and FacilityCode: $FacilityCode" -logfile $LogFileName;
            Write-Log -Level INFO -Message $UpdateAccountJson -logfile $LogFileName;
            

            $UpdateAcntResponse = $null
            $UpdateAccountStatusParams = @{
                EndPoint        = -join ($config.APIBaseURL, $config.APIUpdateAccountStatus)
                token           = $token
                FacilityCode	= $AccountItem.FacilityCode
                jsonbody        = $UpdateAccountJson
            }
            $UpdateAcntResponse = Invoke-udfAPICheckoutAccount @UpdateAccountStatusParams;
        
            if ($UpdateAcntResponse.Success -eq $true) {

                $UpdateAccountjson = $UpdateAcntResponse.AccountDet | ConvertTo-Json -Depth 10;

                if ($UpdateAccountjson) {
                    Write-Log -Level INFO -Message "Response received from Update Account Status API successfully for Account Number: $AccountNumber and FacilityCode: $FacilityCode" -logfile $LogFileName;
                    if ($UpdateAccountjson -eq $true) {
                        Write-Log -Level INFO -Message "Account Status updated successfully for the Account Number: $AccountNumber and FacilityCode: $FacilityCode" -logfile $LogFileName;

                        $ReportDet.ProcessStatus = "Pass";
                        $ReportDet.EndProcess = (Get-date -Format "yyyy-MM-dd HH:mm:ss:fff");
                        $DTOspExecParams = @{
                            rptconnstring = $config.PSDBConnectionString
                            rptspname     = $config.DTOReportingSP
                            DTOReportData = $ReportDet
                        }
                        $DTORptDet = Invoke-udfDTOReporting @DTOspExecParams;
                        
                        if ($DTORptDet.Success -eq $false) {
                            Write-Log -Level ERROR -Message "Error during DTO Reporting"  -logfile $LogFileName
                            Write-Log -Level ERROR -Message  $DTORptDet.Errors.Exception.Message -logfile $LogFileName
                        }                                                
                    }
                    else {
                        Write-Log -Level ERROR -Message "Error while updating account status for Account Number: $AccountNumber and FacilityCode: $FacilityCode" -logfile $LogFileName -ErrorAction Stop;
                        Write-Log -Level ERROR -Message $UpdateAccountjson -logfile $LogFileName -ErrorAction Stop;
                        $ReportDet.ProcessStatus = "Fail"
                        $ReportDet.StatusDescription = "Error while updating account status";
                        $ReportDet.EndProcess = (Get-date -Format "yyyy-MM-dd HH:mm:ss:fff");
        
                        $DTOspExecParams = @{
                            rptconnstring = $config.PSDBConnectionString
                            rptspname     = $config.DTOReportingSP
                            DTOReportData = $ReportDet
                        }
                        $DTORptDet = Invoke-udfDTOReporting @DTOspExecParams;
                        
                        if ($DTORptDet.Success -eq $false) {
                            Write-Log -Level ERROR -Message "Error during DTO Reporting"  -logfile $LogFileName
                            Write-Log -Level ERROR -Message  $DTORptDet.Errors.Exception.Message -logfile $LogFileName
                        }                        
                    }                    

                } 

            }
            else {
                
                Write-Log -Level ERROR -Message "Error during Update Account Status API call for account number: $AccountNumber and FacilityCode: $FacilityCode" -logfile $LogFileName -ErrorAction Stop;
                Write-Log -Level ERROR -Message $UpdateAcntResponse.Errors.Exception.Message -logfile $LogFileName -ErrorAction Stop
                if ($UpdateAcntResponse.Errors.ErrorDetails.Message) {
                    Write-Log -Level ERROR -Message $UpdateAcntResponse.Errors.ErrorDetails.Message -logfile $LogFileName -ErrorAction Stop
                }
                $ReportDet.ProcessStatus = "Fail"
                $ReportDet.StatusDescription = $UpdateAcntResponse.Errors.Exception.Message;
                $ReportDet.EndProcess = (Get-date -Format "yyyy-MM-dd HH:mm:ss:fff");

                $DTOspExecParams = @{
                    rptconnstring = $config.PSDBConnectionString
                    rptspname     = $config.DTOReportingSP
                    DTOReportData = $ReportDet
                }
                $DTORptDet = Invoke-udfDTOReporting @DTOspExecParams;
                
                if ($DTORptDet.Success -eq $false) {
                    Write-Log -Level ERROR -Message "Error during DTO Reporting"  -logfile $LogFileName
                    Write-Log -Level ERROR -Message  $DTORptDet.Errors.Exception.Message -logfile $LogFileName
                }
		        
            }
        }
    }
    else {
        Write-Host ('No Accounts to be updated.')       
        Write-Log -Level INFO -Message "No Pending accounts to be updated. All accounts have been updated." -logfile $LogFileName             
    } 

}
else {
    Write-Log -Level ERROR -Message "Erro occured while fetching details for updating account status." -logfile $LogFileName -ErrorAction Stop;
    Write-Log -Level ERROR -Message $AccountData.Errors.Exception.Message -logfile $LogFileName -ErrorAction Stop;
}

#endregion Checkout Account
Write-Log -Level INFO -Message "Update Account Status process completed." -logfile $LogFileName
Write-Log -Level INFO -Message "End of Bot execution." -logfile $LogFileName
Write-Host "End of Bot Execution."

